# -*- coding: utf-8 -*-
# Copyright 2017 Dodd Gray
"""
Package containing drivers for temperature controllers.
"""
from .. import Instrument


class TempController(Instrument):
    pass
