# -*- coding: utf-8 -*-
# Copyright 2015 Nate Bogdanowicz
"""
Package containing drivers for spectrometers.
"""
from .. import Instrument


class Spectrometer(Instrument):
    pass
