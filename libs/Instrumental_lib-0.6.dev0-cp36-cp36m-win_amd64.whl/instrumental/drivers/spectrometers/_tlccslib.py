# auto-generated file
import _cffi_backend

ffi = _cffi_backend.FFI('._tlccslib',
    _version = 0x2601,
    _types = b'\x00\x00\x21\x0D\x00\x00\x5B\x03\x00\x00\x06\x01\x00\x00\x06\x01\x00\x00\x07\x03\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x01\x11\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x01\x11\x00\x00\x01\x11\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x01\x11\x00\x00\x01\x11\x00\x00\x01\x11\x00\x00\x01\x11\x00\x00\x01\x11\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x27\x03\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x1C\x11\x00\x00\x09\x01\x00\x00\x09\x01\x00\x00\x09\x01\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x0E\x01\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x21\x03\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x2B\x11\x00\x00\x01\x11\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x2B\x11\x00\x00\x1C\x11\x00\x00\x2B\x11\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x2B\x11\x00\x00\x1C\x11\x00\x00\x09\x01\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x09\x01\x00\x00\x01\x11\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x4A\x03\x00\x00\x01\x11\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x05\x01\x00\x00\x1C\x11\x00\x00\x1C\x11\x00\x00\x1C\x11\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x0A\x01\x00\x00\x04\x11\x00\x00\x00\x0F\x00\x00\x21\x0D\x00\x00\x0A\x01\x00\x00\x0A\x01\x00\x00\x0A\x01\x00\x00\x00\x0F\x00\x00\x01\x03\x00\x00\x5B\x03\x00\x00\x02\x01\x00\x00\x5D\x03\x00\x00\x0D\x01\x00\x00\x5F\x03\x00\x00\x03\x01\x00\x00\x61\x03\x00\x00\x63\x03\x00\x00\x63\x03\x00\x00\x04\x01\x00\x00\x02\x03\x00\x00\x66\x03\x00\x00\x67\x03\x00\x00\x00\x01',
    _globals = (b'\x00\x00\x06\x23tlccs_close',0,b'\x00\x00\x3E\x23tlccs_error_message',0,b'\x00\x00\x2D\x23tlccs_error_query',0,b'\x00\x00\x1E\x23tlccs_getAmplitudeData',0,b'\x00\x00\x4F\x23tlccs_getAttribute',0,b'\x00\x00\x29\x23tlccs_getDeviceStatus',0,b'\x00\x00\x1A\x23tlccs_getIntegrationTime',0,b'\x00\x00\x29\x23tlccs_getRawScanData',0,b'\x00\x00\x1A\x23tlccs_getScanData',0,b'\x00\x00\x32\x23tlccs_getUserCalibrationPoints',0,b'\x00\x00\x09\x23tlccs_getUserText',0,b'\x00\x00\x48\x23tlccs_getWavelengthData',0,b'\x00\x00\x12\x23tlccs_identificationQuery',0,b'\x00\x00\x00\x23tlccs_init',0,b'\x00\x00\x06\x23tlccs_reset',0,b'\x00\x00\x0D\x23tlccs_revision_query',0,b'\x00\x00\x43\x23tlccs_self_test',0,b'\x00\x00\x1E\x23tlccs_setAmplitudeData',0,b'\x00\x00\x54\x23tlccs_setAttribute',0,b'\x00\x00\x25\x23tlccs_setIntegrationTime',0,b'\x00\x00\x09\x23tlccs_setUserText',0,b'\x00\x00\x38\x23tlccs_setWavelengthData',0,b'\x00\x00\x06\x23tlccs_startScan',0,b'\x00\x00\x06\x23tlccs_startScanCont',0,b'\x00\x00\x06\x23tlccs_startScanContExtTrg',0,b'\x00\x00\x06\x23tlccs_startScanExtTrg',0),
    _typenames = (b'\x00\x00\x00\x65ViAAddr',b'\x00\x00\x00\x64ViABoolean',b'\x00\x00\x00\x60ViABuf',b'\x00\x00\x00\x61ViAByte',b'\x00\x00\x00\x01ViAChar',b'\x00\x00\x00\x45ViAInt16',b'\x00\x00\x00\x2BViAInt32',b'\x00\x00\x00\x5EViAInt8',b'\x00\x00\x00\x04ViAObject',b'\x00\x00\x00\x5CViAReal32',b'\x00\x00\x00\x1CViAReal64',b'\x00\x00\x00\x59ViARsrc',b'\x00\x00\x00\x04ViASession',b'\x00\x00\x00\x2BViAStatus',b'\x00\x00\x00\x59ViAString',b'\x00\x00\x00\x64ViAUInt16',b'\x00\x00\x00\x04ViAUInt32',b'\x00\x00\x00\x61ViAUInt8',b'\x00\x00\x00\x04ViAVersion',b'\x00\x00\x00\x66ViAddr',b'\x00\x00\x00\x07ViAttr',b'\x00\x00\x00\x07ViAttrState',b'\x00\x00\x00\x02ViBoolean',b'\x00\x00\x00\x61ViBuf',b'\x00\x00\x00\x63ViByte',b'\x00\x00\x00\x5BViChar',b'\x00\x00\x00\x62ViConstBuf',b'\x00\x00\x00\x5AViConstRsrc',b'\x00\x00\x00\x5AViConstString',b'\x00\x00\x00\x4AViInt16',b'\x00\x00\x00\x21ViInt32',b'\x00\x00\x00\x5FViInt8',b'\x00\x00\x00\x07ViObject',b'\x00\x00\x00\x65ViPAddr',b'\x00\x00\x00\x64ViPBoolean',b'\x00\x00\x00\x61ViPBuf',b'\x00\x00\x00\x61ViPByte',b'\x00\x00\x00\x01ViPChar',b'\x00\x00\x00\x45ViPInt16',b'\x00\x00\x00\x2BViPInt32',b'\x00\x00\x00\x5EViPInt8',b'\x00\x00\x00\x04ViPObject',b'\x00\x00\x00\x5CViPReal32',b'\x00\x00\x00\x1CViPReal64',b'\x00\x00\x00\x01ViPRsrc',b'\x00\x00\x00\x04ViPSession',b'\x00\x00\x00\x2BViPStatus',b'\x00\x00\x00\x01ViPString',b'\x00\x00\x00\x64ViPUInt16',b'\x00\x00\x00\x04ViPUInt32',b'\x00\x00\x00\x61ViPUInt8',b'\x00\x00\x00\x04ViPVersion',b'\x00\x00\x00\x5DViReal32',b'\x00\x00\x00\x27ViReal64',b'\x00\x00\x00\x01ViRsrc',b'\x00\x00\x00\x07ViSession',b'\x00\x00\x00\x21ViStatus',b'\x00\x00\x00\x01ViString',b'\x00\x00\x00\x02ViUInt16',b'\x00\x00\x00\x07ViUInt32',b'\x00\x00\x00\x63ViUInt8',b'\x00\x00\x00\x07ViVersion'),
)

import os
import os.path
build_version = '0.6'

# Change directory in case of dependent libs not on PATH
_old_curdir = os.path.abspath(os.curdir)
if 'C:\\Windows\\system32':
    os.chdir('C:\\Windows\\system32')
lib = ffi.dlopen('C:\\Windows\\system32\\TLCCS_64.dll')
os.chdir(_old_curdir)

# Generated macro definitions
defs = {}
defs['VI_WARN_NSUP_ID_QUERY'] = 1073479937
defs['VI_WARN_NSUP_RESET'] = 1073479938
defs['VI_WARN_NSUP_SELF_TEST'] = 1073479939
defs['VI_WARN_NSUP_ERROR_QUERY'] = 1073479940
defs['VI_WARN_NSUP_REV_QUERY'] = 1073479941
defs['VI_ERROR_PARAMETER1'] = (((-2147483647)-1)+1073479681)
defs['VI_ERROR_PARAMETER2'] = (((-2147483647)-1)+1073479682)
defs['VI_ERROR_PARAMETER3'] = (((-2147483647)-1)+1073479683)
defs['VI_ERROR_PARAMETER4'] = (((-2147483647)-1)+1073479684)
defs['VI_ERROR_PARAMETER5'] = (((-2147483647)-1)+1073479685)
defs['VI_ERROR_PARAMETER6'] = (((-2147483647)-1)+1073479686)
defs['VI_ERROR_PARAMETER7'] = (((-2147483647)-1)+1073479687)
defs['VI_ERROR_PARAMETER8'] = (((-2147483647)-1)+1073479688)
defs['VI_ERROR_FAIL_ID_QUERY'] = (((-2147483647)-1)+1073479697)
defs['VI_ERROR_INV_RESPONSE'] = (((-2147483647)-1)+1073479698)
defs['VI_ON'] = 1
defs['VI_OFF'] = 0
defs['_VI_ERROR'] = ((-2147483647)-1)
defs['TLCCS_FIND_PATTERN'] = "USB?*?{VI_ATTR_MANF_ID==0x1313 && ((VI_ATTR_MODEL_CODE==0x8081) || (VI_ATTR_MODEL_CODE==0x8083) || (VI_ATTR_MODEL_CODE==0x8085) || (VI_ATTR_MODEL_CODE==0x8087) || (VI_ATTR_MODEL_CODE==0x8089))}"
defs['TLCCS_VID'] = 4883
defs['CCS100_PID'] = 32897
defs['CCS125_PID'] = 32899
defs['CCS150_PID'] = 32901
defs['CCS175_PID'] = 32903
defs['CCS200_PID'] = 32905
defs['TLCCS_EXTRACT_MAJOR'] = lambda revision: ((revision&4293918720)>>20)
defs['TLCCS_EXTRACT_MINOR'] = lambda revision: ((revision&1048320)>>8)
defs['TLCCS_EXTRACT_SUBMINOR'] = lambda revision: (revision&255)
defs['TLCCS_TIMEOUT_MIN'] = 1000
defs['TLCCS_TIMEOUT_DEF'] = 2000
defs['TLCCS_TIMEOUT_MAX'] = 60000
defs['TLCCS_BUFFER_SIZE'] = 256
defs['TLCCS_ERR_DESCR_BUFFER_SIZE'] = 512
defs['TLCCS_TEXT_BUFFER_SIZE'] = 256
defs['TLCCS_NUM_PIXELS'] = 3648
defs['TLCCS_NUM_RAW_PIXELS'] = 3694
defs['TLCCS_MAX_USER_NAME_SIZE'] = 32
defs['TLCCS_MIN_NUM_USR_ADJ'] = 4
defs['TLCCS_MAX_NUM_USR_ADJ'] = 10
defs['TLCCS_ATTR_USER_DATA'] = 1073676295
defs['TLCCS_ATTR_CAL_MODE'] = 1073348608
defs['TLCCS_CAL_MODE_USER'] = 0
defs['TLCCS_CAL_MODE_THORLABS'] = 1
defs['VI_ERROR_NSUP_COMMAND'] = (((-2147483647)-1)+1073481729)
defs['VI_ERROR_TLCCS_UNKNOWN'] = (((-2147483647)-1)+1073481730)
defs['VI_ERROR_SCAN_DATA_INVALID'] = (((-2147483647)-1)+1073481731)
defs['VI_ERROR_XSVF_SIZE'] = (((-2147483647)-1)+1073482240)
defs['VI_ERROR_XSVF_MEMORY'] = (((-2147483647)-1)+1073482241)
defs['VI_ERROR_XSVF_FILE'] = (((-2147483647)-1)+1073482242)
defs['VI_ERROR_FIRMWARE_SIZE'] = (((-2147483647)-1)+1073482256)
defs['VI_ERROR_FIRMWARE_MEMORY'] = (((-2147483647)-1)+1073482257)
defs['VI_ERROR_FIRMWARE_FILE'] = (((-2147483647)-1)+1073482258)
defs['VI_ERROR_FIRMWARE_CHKSUM'] = (((-2147483647)-1)+1073482259)
defs['VI_ERROR_FIRMWARE_BUFOFL'] = (((-2147483647)-1)+1073482260)
defs['VI_ERROR_CYEEPROM_SIZE'] = (((-2147483647)-1)+1073482272)
defs['VI_ERROR_CYEEPROM_MEMORY'] = (((-2147483647)-1)+1073482273)
defs['VI_ERROR_CYEEPROM_FILE'] = (((-2147483647)-1)+1073482274)
defs['VI_ERROR_CYEEPROM_CHKSUM'] = (((-2147483647)-1)+1073482275)
defs['VI_ERROR_CYEEPROM_BUFOVL'] = (((-2147483647)-1)+1073482276)
defs['VI_ERROR_USBCOMM_OFFSET'] = (((-2147483647)-1)+1073482496)
defs['VI_ERROR_TLCCS_ENDP0_SIZE'] = ((((-2147483647)-1)+1073482496)+1)
defs['VI_ERROR_TLCCS_EEPROM_ADR_TO_BIG'] = ((((-2147483647)-1)+1073482496)+2)
defs['VI_ERROR_TLCCS_XSVF_UNKNOWN'] = ((((-2147483647)-1)+1073482496)+17)
defs['VI_ERROR_TLCCS_XSVF_TDOMISMATCH'] = ((((-2147483647)-1)+1073482496)+18)
defs['VI_ERROR_TLCCS_XSVF_MAXRETRIES'] = ((((-2147483647)-1)+1073482496)+19)
defs['VI_ERROR_TLCCS_XSVF_ILLEGALCMD'] = ((((-2147483647)-1)+1073482496)+20)
defs['VI_ERROR_TLCCS_XSVF_ILLEGALSTATE'] = ((((-2147483647)-1)+1073482496)+21)
defs['VI_ERROR_TLCCS_XSVF_DATAOVERFLOW'] = ((((-2147483647)-1)+1073482496)+22)
defs['VI_ERROR_TLCCS_I2C_NACK'] = ((((-2147483647)-1)+1073482496)+32)
defs['VI_ERROR_TLCCS_I2C_ERR'] = ((((-2147483647)-1)+1073482496)+33)
defs['VI_ERROR_TLCCS_READ_INCOMPLETE'] = ((((-2147483647)-1)+1073482496)+64)
defs['VI_ERROR_TLCCS_NO_USER_DATA'] = ((((-2147483647)-1)+1073482496)+65)
defs['VI_ERROR_TLCCS_INV_USER_DATA'] = ((((-2147483647)-1)+1073482496)+66)
defs['VI_ERROR_TLCCS_INV_ADJ_DATA'] = ((((-2147483647)-1)+1073482496)+67)
defs['VI_SUCCESS'] = 0
defs['VI_NULL'] = 0
defs['VI_TRUE'] = 1
defs['VI_FALSE'] = 0
defs['TLCCS_STATUS_SCAN_IDLE'] = 2
defs['TLCCS_STATUS_SCAN_TRIGGERED'] = 4
defs['TLCCS_STATUS_SCAN_START_TRANS'] = 8
defs['TLCCS_STATUS_SCAN_TRANSFER'] = 16
defs['TLCCS_STATUS_WAIT_FOR_EXT_TRIG'] = 128
defs['TLCCS_CAL_DATA_SET_FACTORY'] = 0
defs['TLCCS_CAL_DATA_SET_USER'] = 1
defs['ACOR_APPLY_TO_MEAS'] = 1
defs['ACOR_APPLY_TO_MEAS_NVMEM'] = 2
defs['ACOR_FROM_CURRENT'] = 1
defs['ACOR_FROM_NVMEM'] = 2


argnames = {'tlccs_init': ['rsrcName', 'id_query', 'reset_instr', 'vi'], 'tlccs_close': ['vi'], 'tlccs_setIntegrationTime': ['vi', 'integrationTime'], 'tlccs_getIntegrationTime': ['vi', 'integrationTime'], 'tlccs_startScan': ['vi'], 'tlccs_startScanCont': ['vi'], 'tlccs_startScanExtTrg': ['vi'], 'tlccs_startScanContExtTrg': ['vi'], 'tlccs_getDeviceStatus': ['vi', 'deviceStatus'], 'tlccs_getScanData': ['vi', 'data'], 'tlccs_getRawScanData': ['vi', 'scanDataArray'], 'tlccs_setWavelengthData': ['vi', 'pixelDataArray', 'wavelengthDataArray', 'bufferLength'], 'tlccs_getWavelengthData': ['vi', 'dataSet', 'wavelengthDataArray', 'minimumWavelength', 'maximumWavelength'], 'tlccs_getUserCalibrationPoints': ['vi', 'pixelDataArray', 'wavelengthDataArray', 'bufferLength'], 'tlccs_setAmplitudeData': ['vi', 'AmpCorrFact', 'bufferLength', 'bufferStart', 'mode'], 'tlccs_getAmplitudeData': ['vi', 'AmpCorrFact', 'bufferStart', 'bufferLength', 'mode'], 'tlccs_identificationQuery': ['vi', 'manufacturerName', 'deviceName', 'serialNumber', 'firmwareRevision', 'instrumentDriverRevision'], 'tlccs_revision_query': ['vi', 'driver_rev', 'instr_rev'], 'tlccs_reset': ['vi'], 'tlccs_self_test': ['vi', 'test_result', 'test_message'], 'tlccs_error_query': ['vi', 'error_code', 'error_message'], 'tlccs_error_message': ['vi', 'status_code', 'message'], 'tlccs_setAttribute': ['vi', 'attribute', 'value'], 'tlccs_getAttribute': ['vi', 'attribute', 'value'], 'tlccs_setUserText': ['vi', 'userText'], 'tlccs_getUserText': ['vi', 'userText']}
